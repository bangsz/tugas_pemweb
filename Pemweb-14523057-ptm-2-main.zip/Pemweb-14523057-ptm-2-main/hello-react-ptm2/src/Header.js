// import libraries
import React from 'react';

//membuat component dengan class
class Header extends React.Component{
    render(){
      return(
        <div>
          <h2>Makanan Khas Indonesia</h2>
        </div>
      );
    }
  }

export default Header
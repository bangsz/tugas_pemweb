// import libraries
import React from 'react';
import Header from './Header';

//create component
const App = () => {
  return (
    <div>
      <h1>Hello React</h1>
      <p><b>BAMBANG GANTENG</b></p>
      <Header />
    </div>
  );
};
//export default
export default App;

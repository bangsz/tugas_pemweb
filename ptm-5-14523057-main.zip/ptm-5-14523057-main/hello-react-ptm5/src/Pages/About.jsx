const About =() =>{
    return(
        <>
        <h1>Ini Halaman About</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
            Recusandae, iusto quia. 
            Soluta, laudantium voluptatibus consequatur, 
            perspiciatis quisquam magnam ipsum quos architecto 
            possimus corrupti a. 
            Illo autem architecto ab voluptate exercitationem!</p>
        </>
    )
}
export default About
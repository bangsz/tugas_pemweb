<?php
$buah = ["mangga", "apple", "jeruk"];
echo $buah[1];
echo $buah[2];
echo "<br>";

$mhs = [
    'nama' => "Kholiddd",
    'nim' => "14523058",
    'jurusan' => "Informatika",
];
echo $mhs['nama'];
echo " ";
echo $mhs['nim'];
echo " ";

$multiArr = [
    ['ariz', 14523057, "Informatika"],
    ['Rahmad', 14523059, "Informatika"],
];
echo $multiArr[0][2];

for ($i = 0; $i < count($buah); $i++) {
    echo "$buah[$i]" . "<br>";
}

foreach ($mhs as $key => $value) {
    echo "$key : $value <br>";
}

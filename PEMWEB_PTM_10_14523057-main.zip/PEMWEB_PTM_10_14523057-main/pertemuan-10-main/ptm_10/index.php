<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pertemuan 10</title>
</head>

<body>
    <h1>pertemuan 10</h1>
    <a href="if.php">Materi If</a>
    <br>
    <br>
    <a href="switch.php">Materi Switch</a>
    <br>
    <br>
    <a href="for.php">Materi For</a>
    <br>
    <br>
    <a href="function.php">Materi Function</a>
    <br>
    <br>
    <a href="array.php">Materi Array</a>
    <br>
    <br>
    <a href="form_handle.php">Materi form</a>
</body>

</html>
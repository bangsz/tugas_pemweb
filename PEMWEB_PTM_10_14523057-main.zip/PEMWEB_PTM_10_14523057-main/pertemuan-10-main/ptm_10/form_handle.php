<form action = "proses.php">
    nama : <input type = "text" name = "nama"><br>
    Gender :
    <input type = "radio" name = "gender" value = "Laki-laki"> laki-laki
    <input type = "radio" name = "gender" value = "Perempuan"> perempuan <br>
    Hobi :
    <input type = "checkbox" name = "hobi" value = "Membaca"> membaca 
    <input type = "checkbox" name = "hobi" value = "Menulis"> menulis <br>
    Jurusan :
    <select name = "jurusan" id ="">
        <option value = "Teknik Informatika"> Teknik Informatika</option>
        <option value = "Sistem Informasi"> Sistem Informasi</option>
    </select>

    <input type = "submit" value = "Kirim">
</form>
<?php
echo "<h1> codingan function </h1>";
echo "Tanpa parameter : <br>";

function salam()
{
    echo "Halo, saya codingan";
}
salam();
echo "dengan parameter <br>";

function namaAnda($name)
{
    echo "selamat datang php, $name";
}
namaAnda("Kholiddd");
echo "<br>";

echo "dengan parameter default <br>";
function salam2($name = "user")
{
    echo "selamat datang hallo $name <br>";
}
salam2();
salam2("Rizz");
echo "<br>";

function jumlah($a, $b)
{
    return $a + $b;
}
$hasil = jumlah(70, 198);
echo "hasil :" . $hasil;

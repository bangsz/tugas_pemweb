import React from "react";

function Footer() {
  const namaMhs = "Muhammad Ariz";
  return (
    <div>
      <h3>Ini adalah halaman Footer</h3>
      <footer> 🚀 Design with 💖 by {namaMhs} </footer>
    </div>
  );
}
export default Footer;

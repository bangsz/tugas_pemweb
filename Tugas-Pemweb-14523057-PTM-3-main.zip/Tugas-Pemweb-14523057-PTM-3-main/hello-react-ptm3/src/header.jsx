// Import Libraries
import React from "react";
//create componenet
class Header extends React.Component{
    render() {
      return (
          <div>
            <h2>ini Makanan Khas Indonesia</h2>
          </div>
      );
    }
}  
// export component 
export default Header;

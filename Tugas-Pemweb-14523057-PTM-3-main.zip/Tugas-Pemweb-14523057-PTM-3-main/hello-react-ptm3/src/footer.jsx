import React from "react";

function Footer() {
  const namaMhs = "Muhammad Ariz";
  return (
    <div>
      <h3>ini adalah Halaman Footer</h3>
      <footer>🐱‍🚀 Design by 👍 {namaMhs} </footer>
    </div>
  );
}
export default Footer;
